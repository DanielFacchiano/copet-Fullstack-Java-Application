package com.wolves.copet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CopetApplication {

	public static void main(String[] args) {
		SpringApplication.run(CopetApplication.class, args);
	}
}
