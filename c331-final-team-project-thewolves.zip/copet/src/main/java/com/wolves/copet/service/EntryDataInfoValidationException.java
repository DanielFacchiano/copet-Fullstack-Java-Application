package com.wolves.copet.service;

public class EntryDataInfoValidationException extends Exception{

    public EntryDataInfoValidationException(String message) { super(message); }
}
