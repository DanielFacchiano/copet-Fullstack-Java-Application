package com.wolves.copet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CopetApplicationTests {

	@Test
	void contextLoads() {
	}

}
